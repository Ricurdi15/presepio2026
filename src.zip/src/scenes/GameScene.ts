import Phaser from 'phaser';
import { CONFIG } from '../config';
import type { PickupDef, ObstacleDef } from '../config';
import { DebugGizmos } from '../debug';
import { objectBox, overlaps, playerBox, sameLane } from '../hitbox';
import type { WorldObj } from '../hitbox';
import { leaderboard } from '../leaderboard';
import { textStyle } from '../ui';

type GameState = 'playing' | 'dying' | 'over';
type Keys = Record<'up' | 'down' | 'w' | 's' | 'space', Phaser.Input.Keyboard.Key>;

const lerp = Phaser.Math.Linear;

export class GameScene extends Phaser.Scene {
  private playerName = 'Player';

  private state: GameState = 'playing';
  private score = 0;
  private lives = 0;
  private speed = 0;
  private elapsed = 0;          // secondi di gioco effettivo (guida la difficolta')
  private lane = 1;
  private py = 0;               // Y a terra del player (si muove fluida tra le corsie)
  private height = 0;           // altezza del salto
  private vy = 0;
  private grounded = true;
  private jumpBuf = 0;
  private invul = 0;
  private animT = 0;
  private spawnTimer = 0;
  private nextGapSec = 0;
  private objects: WorldObj[] = [];

  private runFrames: string[] = [];
  private curKey = '';
  private player!: Phaser.GameObjects.Image;
  private shadow!: Phaser.GameObjects.Image;
  private dashes: Phaser.GameObjects.TileSprite[] = [];
  private livesText!: Phaser.GameObjects.Text;
  private scoreText!: Phaser.GameObjects.Text;
  private gizmos!: DebugGizmos;

  private keys!: Keys;
  private laneDelta = 0;
  private jumpPressed = false;
  private swipeStart = new Map<number, number>();
  private jumpPointers = new Set<number>();

  constructor() {
    super('Game');
  }

  init(data: { name?: string }): void {
    this.playerName = data.name ?? 'Player';
  }

  create(): void {
    const C = CONFIG;
    this.cameras.main.setBackgroundColor('#87CEEB');

    // ---------- percorso: erba + 3 sentieri + trattini che scorrono ----------
    this.add.rectangle(C.width / 2, 510, C.width, 420, 0x59a64d).setDepth(-300);
    this.dashes = [];
    C.laneY.forEach((ly, i) => {
      this.add.rectangle(C.width / 2, ly - 30, C.width, 100, i % 2 ? 0xb38c5c : 0xc29a66).setDepth(-200);
      this.dashes.push(this.add.tileSprite(C.width / 2, ly + 10, C.width, 6, 'dash').setDepth(-100));
    });

    // ---------- stato ----------
    this.state = 'playing';
    this.score = 0;
    this.lives = C.maxLives;
    this.speed = C.difficulty.startSpeed;
    this.elapsed = 0;
    this.lane = 1;
    this.py = C.laneY[1];
    this.height = 0;
    this.vy = 0;
    this.grounded = true;
    this.jumpBuf = 0;
    this.invul = 0;
    this.animT = 0;
    this.objects = [];
    this.spawnTimer = 0;
    this.nextGapSec = 0.6;     // prima riga quasi subito (solo raccoglibili: c'e' il periodo di grazia)

    // ---------- player ----------
    this.runFrames = [];
    for (let i = 0; this.textures.exists(`player_run_${i}`); i++) this.runFrames.push(`player_run_${i}`);
    this.shadow = this.add.image(C.playerX, this.py, 'shadow');
    this.player = this.add.image(C.playerX, this.py, this.runFrames[0]).setOrigin(0.5, 1);
    this.curKey = '';
    this.setPlayerTexture(this.runFrames[0]);

    // ---------- HUD: vite a sinistra, punteggio a destra ----------
    const hudStyle = textStyle(40, '#ffffff', { stroke: '#000000', strokeThickness: 5 });
    this.livesText = this.add.text(24, 16, '', hudStyle).setDepth(1000);
    this.scoreText = this.add.text(C.width - 24, 16, '', hudStyle).setOrigin(1, 0).setDepth(1000);

    this.gizmos = new DebugGizmos(this);

    // ---------- input ----------
    const kb = this.input.keyboard!;
    this.keys = kb.addKeys({ up: 'UP', down: 'DOWN', w: 'W', s: 'S', space: 'SPACE' }) as Keys;
    this.laneDelta = 0;
    this.jumpPressed = false;
    this.swipeStart.clear();
    this.jumpPointers.clear();
    this.input.addPointer(2);

    // touch: meta' sinistra = swipe su/giu (corsia), meta' destra = tieni premuto per saltare
    this.input.on('pointerdown', (p: Phaser.Input.Pointer) => {
      if (p.x > C.width / 2) {
        this.jumpPointers.add(p.id);
        this.jumpPressed = true;
      } else {
        this.swipeStart.set(p.id, p.y);
      }
    });
    this.input.on('pointermove', (p: Phaser.Input.Pointer) => {
      if (!p.isDown) return;
      const startY = this.swipeStart.get(p.id);
      if (startY === undefined) return;
      const dy = p.y - startY;
      if (Math.abs(dy) >= C.swipeThreshold) {
        this.laneDelta += dy < 0 ? 1 : -1;   // swipe verso l'alto = corsia piu' lontana
        this.swipeStart.delete(p.id);        // una corsia per swipe
      }
    });
    const release = (p: Phaser.Input.Pointer): void => {
      this.jumpPointers.delete(p.id);
      this.swipeStart.delete(p.id);
    };
    this.input.on('pointerup', release);
    this.input.on('pointerupoutside', release);

    this.refreshHud();
  }

  private setPlayerTexture(key: string): void {
    if (this.curKey === key) return;
    this.curKey = key;
    this.player.setTexture(key).setDisplaySize(CONFIG.playerSize, CONFIG.playerSize);
  }

  private refreshHud(): void {
    this.livesText.setText(`VITE: ${this.lives}`);
    this.scoreText.setText(`PUNTI: ${this.score}`);
  }

  // ---------- difficolta' ----------
  /** 0 (inizio) -> 1 (massimo), in base al tempo di gioco. */
  private difficulty(): number {
    return Math.min(1, this.elapsed / CONFIG.difficulty.rampSeconds);
  }

  // ---------- spawn ----------
  private spawnRow(): void {
    const C = CONFIG;
    const D = C.difficulty;
    const d = this.difficulty();
    const x = C.width + 80;

    const obstacleChance = this.elapsed < D.graceSeconds ? 0 : lerp(D.obstacleChance.start, D.obstacleChance.end, d);
    const pickupChance = lerp(D.pickupChance.start, D.pickupChance.end, d);
    const maxObstacles = d >= D.twoObstaclesFrom ? 2 : 1;
    const available = C.obstacles.filter((o) => o.minDifficulty <= d);

    let obstacleCount = 0;
    for (const ly of C.laneY) {
      const r = Math.random();
      if (r < obstacleChance && obstacleCount < maxObstacles && available.length > 0) {
        this.spawnObstacle(Phaser.Utils.Array.GetRandom(available), ly, x);
        obstacleCount++;
      } else if (r < obstacleChance + pickupChance) {
        this.spawnPickup(this.pickWeighted(), ly, x);
      }
    }

    // prossima riga: i tempi si accorciano con la difficolta' (e a velocita' piu' alta = piu' pixel)
    const g = D.gapSeconds;
    this.nextGapSec = Phaser.Math.FloatBetween(
      lerp(g.start[0], g.end[0], d),
      lerp(g.start[1], g.end[1], d),
    );
  }

  private pickWeighted(): PickupDef {
    const list = CONFIG.pickups;
    let roll = Math.random() * list.reduce((sum, p) => sum + p.weight, 0);
    for (const p of list) {
      roll -= p.weight;
      if (roll <= 0) return p;
    }
    return list[0];
  }

  private spawnObstacle(t: ObstacleDef, ly: number, x: number): void {
    const k = CONFIG.hitbox.obstacleScale;
    const s = this.add.image(x, ly, t.key).setOrigin(0.5, 1).setDisplaySize(t.width, t.height).setDepth(ly);
    this.objects.push({ s, kind: 'obstacle', laneY: ly, hitW: t.width * k, hitH: t.height * k, z: 0, points: 0, done: false });
  }

  private spawnPickup(t: PickupDef, ly: number, x: number): void {
    const k = CONFIG.hitbox.pickupScale;
    const s = this.add.image(x, ly - t.elevation, t.key).setOrigin(0.5, 1).setDisplaySize(t.width, t.height).setDepth(ly + 2);
    this.objects.push({ s, kind: 'pickup', laneY: ly, hitW: t.width * k, hitH: t.height * k, z: t.elevation, points: t.points, done: false });
  }

  // ---------- eventi di gioco ----------
  private loseLife(): void {
    this.lives--;
    this.invul = CONFIG.invulnerableTime;
    this.refreshHud();
    if (this.lives <= 0) this.die();
  }

  private die(): void {
    this.state = 'dying';
    this.player.setVisible(true);
    this.setPlayerTexture('player_dead');
    this.time.delayedCall(1200, () => {
      void this.finish();
    });
  }

  private async finish(): Promise<void> {
    this.state = 'over';
    const win = this.score >= CONFIG.targetScore;
    try {
      await leaderboard.submit(this.playerName, this.score);
    } catch (e) {
      console.error(e);
    }
    this.scene.start('GameOver', { name: this.playerName, score: this.score, win });
  }

  // ---------- loop ----------
  update(_time: number, delta: number): void {
    const C = CONFIG;
    const dt = Math.min(delta / 1000, 0.05);

    // in verticale (telefono) il gioco va in pausa: l'overlay HTML chiede di ruotare
    if (window.innerHeight > window.innerWidth) return;
    if (this.state === 'over') return;

    const playing = this.state === 'playing';
    const JD = Phaser.Input.Keyboard.JustDown;
    let jumpHeld = false;

    if (playing) {
      const K = this.keys;
      let d = this.laneDelta;
      if (JD(K.up) || JD(K.w)) d += 1;
      if (JD(K.down) || JD(K.s)) d -= 1;
      if (d !== 0) this.lane = Phaser.Math.Clamp(this.lane + Math.sign(d), 0, C.laneY.length - 1);
      if (JD(K.space) || this.jumpPressed) this.jumpBuf = C.jumpBuffer;
      jumpHeld = K.space.isDown || this.jumpPointers.size > 0;

      // progressione: la velocita' sale col tempo fino al massimo
      this.elapsed += dt;
      const D = C.difficulty;
      this.speed = lerp(D.startSpeed, D.maxSpeed, Math.pow(this.difficulty(), D.speedCurve));
    }
    this.laneDelta = 0;
    this.jumpPressed = false;

    // movimento fluido tra corsie
    this.py += (C.laneY[this.lane] - this.py) * (1 - Math.exp(-C.laneSmooth * dt));

    // salto: piu' tieni premuto, piu' sali. Se rilasci in salita la gravita' aumenta.
    this.jumpBuf -= dt;
    if (playing && this.grounded && this.jumpBuf > 0) {
      this.vy = C.jumpVelocity;
      this.grounded = false;
      this.jumpBuf = 0;
    }
    if (!this.grounded) {
      let g = C.gravity;
      if (this.vy > 0 && !jumpHeld) g *= C.releaseGravityMultiplier;
      this.vy -= g * dt;
      this.height += this.vy * dt;
      if (this.height <= 0) {
        this.height = 0;
        this.vy = 0;
        this.grounded = true;
      }
    }

    // mondo
    if (playing) {
      for (const d of this.dashes) d.tilePositionX += this.speed * dt;

      this.spawnTimer += dt;
      if (this.spawnTimer >= this.nextGapSec) {
        this.spawnTimer = 0;
        this.spawnRow();
      }

      const pBox = playerBox(this.height);
      for (let i = this.objects.length - 1; i >= 0; i--) {
        const o = this.objects[i];
        o.s.x -= this.speed * dt;

        // collisione = stessa corsia + hitbox sovrapposte (vedi hitbox.ts)
        if (!o.done && sameLane(o.laneY, this.py) && overlaps(pBox, objectBox(o))) {
          if (o.kind === 'pickup') {
            this.score += o.points;
            this.refreshHud();
            o.s.destroy();
            this.objects.splice(i, 1);
            continue;
          }
          if (this.invul <= 0) {
            o.done = true;
            this.loseLife();
          }
        }
        if (o.s.x < -120) {
          o.s.destroy();
          this.objects.splice(i, 1);
        }
      }
    }

    // grafica player
    this.player.setPosition(C.playerX, this.py - this.height).setDepth(this.py + 1);
    const sh = 1 / (1 + this.height / 200);
    this.shadow.setPosition(C.playerX, this.py + 2).setDepth(this.py).setDisplaySize(64 * sh, 20 * sh);

    if (this.state !== 'dying') {
      if (!this.grounded) {
        this.setPlayerTexture(this.runFrames[Math.min(1, this.runFrames.length - 1)]);
      } else {
        this.animT += dt * C.runAnimFps * (this.speed / C.difficulty.startSpeed);
        this.setPlayerTexture(this.runFrames[Math.floor(this.animT) % this.runFrames.length]);
      }
      this.invul -= dt;
      this.player.setVisible(this.invul <= 0 || Math.floor(this.invul * 12) % 2 === 0);
    }

    this.gizmos.update({
      py: this.py,
      height: this.height,
      player: this.player,
      objects: this.objects,
      stats:
        `t=${this.elapsed.toFixed(0)}s  vel=${this.speed.toFixed(0)}px/s  ` +
        `diff=${(this.difficulty() * 100).toFixed(0)}%  oggetti=${this.objects.length}`,
    });
  }
}
