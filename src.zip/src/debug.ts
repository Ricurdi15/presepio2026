import Phaser from 'phaser';
import { CONFIG, DEBUG } from './config';
import { objectBox, overlaps, playerBox, sameLane } from './hitbox';
import type { Box, WorldObj } from './hitbox';

export interface DebugInfo {
  py: number;                              // Y a terra del player
  height: number;                          // altezza del salto
  player: Phaser.GameObjects.Image;
  objects: WorldObj[];
  stats: string;
}

// Disegna le hitbox usando le STESSE funzioni della collisione, cosi' vedi cio' che il gioco calcola davvero.
export class DebugGizmos {
  private g: Phaser.GameObjects.Graphics | null = null;
  private label: Phaser.GameObjects.Text | null = null;

  constructor(scene: Phaser.Scene) {
    if (!DEBUG.enabled) return;
    this.g = scene.add.graphics().setDepth(2000);
    if (DEBUG.stats) {
      this.label = scene.add
        .text(CONFIG.width / 2, 12, '', { fontFamily: 'monospace', fontSize: '18px', color: '#ffffff', backgroundColor: '#000000aa' })
        .setOrigin(0.5, 0)
        .setDepth(2001);
    }
  }

  update(info: DebugInfo): void {
    const g = this.g;
    if (!g) return;
    g.clear();

    const pBox = playerBox(info.height);

    if (DEBUG.laneBand) {
      const t = CONFIG.laneTolerance;
      g.fillStyle(0x00ffff, 0.1);
      g.fillRect(0, info.py - t, CONFIG.width, t * 2);
      g.lineStyle(1, 0x00ffff, 0.5);
      g.strokeRect(0, info.py - t, CONFIG.width, t * 2);
    }

    if (DEBUG.hitboxes) {
      this.drawBox(info.py, pBox, 0x00ff55);
      for (const o of info.objects) {
        const b = objectBox(o);
        const hit = sameLane(o.laneY, info.py) && overlaps(pBox, b);
        const base = o.kind === 'obstacle' ? 0xff3333 : o.z > 0 ? 0x4dc3ff : 0xffd400;
        this.drawBox(o.laneY, b, hit ? 0xffffff : base);
      }
    }

    if (DEBUG.spriteBounds) {
      g.lineStyle(1, 0x4da6ff, 0.9);
      const pb = info.player.getBounds();
      g.strokeRect(pb.x, pb.y, pb.width, pb.height);
      for (const o of info.objects) {
        const b = o.s.getBounds();
        g.strokeRect(b.x, b.y, b.width, b.height);
      }
    }

    this.label?.setText(info.stats);
  }

  private drawBox(laneY: number, b: Box, color: number): void {
    const g = this.g!;
    const x = b.x0;
    const y = laneY - b.z1;          // z cresce verso l'alto, y dello schermo verso il basso
    const w = b.x1 - b.x0;
    const h = b.z1 - b.z0;
    g.fillStyle(color, 0.18);
    g.fillRect(x, y, w, h);
    g.lineStyle(2, color, 1);
    g.strokeRect(x, y, w, h);
  }
}
