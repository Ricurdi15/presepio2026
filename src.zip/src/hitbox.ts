import type Phaser from 'phaser';
import { CONFIG } from './config';

// Il mondo e' 2.5D: ogni cosa sta su una corsia (profondita') e ha un rettangolo
// in x (orizzontale) e z (altezza da terra). Collisione = stessa corsia + rettangoli sovrapposti.
// Questo file e' l'UNICA fonte di verita': la usano sia il gioco sia i gizmo.

export interface Box {
  x0: number;
  x1: number;
  z0: number;   // altezza da terra (parte bassa)
  z1: number;   // altezza da terra (parte alta)
}

export interface WorldObj {
  s: Phaser.GameObjects.Image;
  kind: 'pickup' | 'obstacle';
  laneY: number;
  hitW: number;
  hitH: number;
  z: number;       // altezza da terra della base della hitbox
  points: number;
  done: boolean;
}

export function playerBox(height: number): Box {
  const { w, h } = CONFIG.hitbox.player;
  return { x0: CONFIG.playerX - w / 2, x1: CONFIG.playerX + w / 2, z0: height, z1: height + h };
}

export function objectBox(o: WorldObj): Box {
  return { x0: o.s.x - o.hitW / 2, x1: o.s.x + o.hitW / 2, z0: o.z, z1: o.z + o.hitH };
}

export function overlaps(a: Box, b: Box): boolean {
  return a.x0 < b.x1 && a.x1 > b.x0 && a.z0 < b.z1 && a.z1 > b.z0;
}

export function sameLane(laneY: number, playerY: number): boolean {
  return Math.abs(laneY - playerY) < CONFIG.laneTolerance;
}
