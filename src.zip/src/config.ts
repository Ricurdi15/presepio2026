// Tutte le regole e i parametri del gioco in un unico posto.
// Unita': pixel su un canvas logico 1280x720 (scalato automaticamente).

export type PickupShape = 'circle' | 'bird';

export interface PickupDef {
  key: string;          // nome texture (e nome file se aggiungi lo sprite vero)
  color: number;        // colore del placeholder
  points: number;
  elevation: number;    // 0 = a terra, >0 = in aria (va preso saltando)
  weight: number;       // piu' alto = piu' frequente
  shape: PickupShape;   // forma del placeholder: 'circle' (a terra) o 'bird' (in aria)
  width: number;        // dimensione a schermo
  height: number;
}

export interface ObstacleDef {
  key: string;
  color: number;
  width: number;        // dimensione a schermo
  height: number;       // il player deve saltare piu' in alto di questo valore
  minDifficulty: number; // 0..1: da quando (nella progressione) puo' comparire
}

// N tipi di oggetti da raccogliere (aggiungine quanti vuoi)
const pickups: PickupDef[] = [
  { key: 'pickup_0', color: 0xffd400, points: 10, elevation: 0,   weight: 1,    shape: 'circle', width: 44, height: 44 },
  { key: 'pickup_1', color: 0x4dc3ff, points: 25, elevation: 105, weight: 0.4,  shape: 'bird',   width: 54, height: 36 }, // in aria
  { key: 'pickup_2', color: 0xff4de6, points: 50, elevation: 0,   weight: 0.15, shape: 'circle', width: 44, height: 44 },
];

// N tipi di ostacoli (aggiungine quanti vuoi). Quelli alti arrivano piu' avanti nella partita.
const obstacles: ObstacleDef[] = [
  { key: 'obstacle_0', color: 0xd93333, width: 65, height: 58,  minDifficulty: 0 },
  { key: 'obstacle_1', color: 0xe68c1a, width: 72, height: 86,  minDifficulty: 0.15 },
  { key: 'obstacle_2', color: 0x8c33b3, width: 50, height: 108, minDifficulty: 0.35 },
];

export const CONFIG = {
  width: 1280,
  height: 720,

  // --- regole ---
  maxLives: 3,
  targetScore: 150,          // punteggio target per la schermata "vittoria"

  // --- progressione: la difficolta' d va da 0 a 1 in rampSeconds secondi di gioco ---
  difficulty: {
    rampSeconds: 300,        // dopo 5 minuti si e' al massimo
    speedCurve: 1,           // 1 = lineare, >1 = parte piu' piano e accelera dopo
    startSpeed: 380,         // px/s all'inizio
    maxSpeed: 1150,          // px/s al massimo (il "limite")
    graceSeconds: 4,         // all'inizio solo oggetti da raccogliere, niente ostacoli
    // tempo (secondi) tra una "riga" di oggetti e la successiva: [min, max]
    gapSeconds: { start: [1.8, 2.6] as [number, number], end: [0.7, 1.05] as [number, number] },
    obstacleChance: { start: 0.06, end: 0.36 },   // probabilita' di ostacolo per corsia
    pickupChance: { start: 0.4, end: 0.3 },       // probabilita' di raccoglibile per corsia
    twoObstaclesFrom: 0.45,  // da questa difficolta' possono esserci 2 ostacoli nella stessa riga (mai 3)
  },

  // --- corsie: Y dei "piedi", indice 0 = corsia in basso (davanti) ---
  laneY: [620, 510, 400],
  laneSmooth: 20,            // piu' alto = cambio corsia piu' rapido (sempre fluido)
  laneTolerance: 43,         // distanza max (px) tra corsia del player e dell'oggetto per poter collidere

  // --- player ---
  playerX: 250,
  playerSize: 86,            // dimensione dello sprite
  runAnimFps: 10,
  invulnerableTime: 1.5,     // secondi di invulnerabilita' dopo un colpo

  // --- hitbox (rettangoli in x/altezza, ancorati ai piedi) ---
  hitbox: {
    player: { w: 40, h: 70 },  // piu' piccola dello sprite (86x86) = piu' "onesta"
    obstacleScale: 0.85,       // hitbox ostacoli = 85% dello sprite
    pickupScale: 1,            // hitbox raccoglibili = 100% dello sprite
  },

  // --- salto stile Mario ---
  jumpVelocity: 800,         // altezza max = v^2 / (2*g) = ~145 px
  gravity: 2200,
  releaseGravityMultiplier: 3, // rilasci in salita -> salto piu' corto
  jumpBuffer: 0.1,

  // --- touch ---
  swipeThreshold: 45,        // px (sinistra schermo = swipe, destra = salto)

  pickups,
  obstacles,
};

// Gizmo di sviluppo. 'enabled' e' true solo con `npm run dev` e si spegne da solo nella build.
// Metti enabled: false per disattivarli del tutto, oppure spegni le singole voci.
export const DEBUG = {
  enabled: import.meta.env.DEV,
  hitboxes: true,       // rettangoli delle hitbox (verde player, rosso ostacoli, giallo oggetti, bianco = collisione)
  laneBand: true,       // fascia azzurra: le corsie che il player "tocca" in questo momento
  spriteBounds: false,  // contorno blu degli sprite (per confrontarli con le hitbox)
  stats: true,          // testo con tempo, velocita', difficolta'
};

// Sprite veri (opzionali). Chiave -> percorso (i file stanno in /public).
// Cio' che lasci fuori usa il placeholder.
// Esempio: 'player_run_0': '/assets/player_run_0.png'
// I frame di corsa si chiamano player_run_0, player_run_1, ... (ne carica quanti ne trova).
export const ASSET_FILES: Record<string, string> = {
  // 'player_run_0': '/assets/player_run_0.png',
  // 'player_dead':  '/assets/player_dead.png',
  // 'pickup_0':     '/assets/coin.png',
  // 'obstacle_0':   '/assets/rock.png',
  // 'win':          '/assets/win.png',
};
